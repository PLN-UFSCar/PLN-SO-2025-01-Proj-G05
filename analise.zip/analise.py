﻿import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud, STOPWORDS
from sklearn.feature_extraction.text import CountVectorizer
from textblob import TextBlob
import spacy
import nltk
from nltk.corpus import stopwords
from requests import get
import math

splits = {'train': 'multilabel/multilabel_train.csv', 'test': 'multilabel/multilabel_test.csv'}
df = pd.read_csv("hf://datasets/Silly-Machine/TuPyE-Dataset/" + splits["train"])

# Colunas de rótulos
labels = [c for c in df.columns if c != "text"][:-3]

# Frequência de unigramas
vec1 = CountVectorizer(ngram_range=(1,1), stop_words="english")
uni = pd.Series(vec1.fit_transform(df.text).sum(axis=0).A1, index=vec1.get_feature_names_out())
plt.figure(figsize=(8,4))
uni.nlargest(20).plot(kind='bar', title="Top 20 Unigrams")
plt.tight_layout(); plt.show()

# Frequência de bigramas
vec2 = CountVectorizer(ngram_range=(2,2), stop_words="english")
bi = pd.Series(vec2.fit_transform(df.text).sum(axis=0).A1, index=vec2.get_feature_names_out())
plt.figure(figsize=(8,4))
bi.nlargest(20).plot(kind='bar', title="Top 20 Bigrams")
plt.tight_layout(); plt.show()

# Matriz de co-ocorrência
# co = df[labels].T.dot(df[labels])
# plt.figure(figsize=(6,6))
# sns.heatmap(co, annot=True, fmt="d", cmap="viridis", cbar=False)
# plt.title("Co-ocorrência de Rótulos")
# plt.tight_layout(); plt.show()

df["neutral"] = (df[labels].sum(axis=1) == 0).astype(int)
labels += ["neutral"]
# Nuvens de palavras por rótulo
custom_stopwords = set(stopwords.words("portuguese")).union({"de", "meu", "minha", "vc", "user", "q", "pra", "rt", "RT"})

n = len(labels)
cols = 3
rows = math.ceil(n / cols)
fig, axes = plt.subplots(rows, cols, figsize=(cols*6, rows*4))  
axes = axes.flatten()

for i, lbl in enumerate(labels):
    texto = " ".join(df.loc[df[lbl] == 1, "text"])
    wc = WordCloud(width=600, height=300, stopwords=custom_stopwords).generate(texto) 
    axes[i].imshow(wc, interpolation="bilinear")
    axes[i].axis("off")
    axes[i].text(
        0.5, 1.02, lbl, transform=axes[i].transAxes,
        ha='center', va='bottom', fontsize=5, weight='bold'
    )

for j in range(i+1, len(axes)):
    axes[j].axis("off")

fig.subplots_adjust(
    left=0.05, right=0.95, top=0.95, bottom=0.08,
    hspace=1, wspace=0.4                         
)

plt.tight_layout()
plt.show()

# Análise de sentimentos
df["polarity"] = df["text"].apply(lambda t: TextBlob(t).sentiment.polarity)
sentiment_mean = {
    lbl: df.loc[df[lbl] == 1, "polarity"].mean()
    for lbl in labels
}

plt.figure(figsize=(8, 4))
sns.barplot(
    x=list(sentiment_mean.keys()),
    y=list(sentiment_mean.values())
)
plt.xticks(rotation=45)
plt.title("Polaridade Média por Rótulo")
plt.tight_layout()
plt.show()
